package model;

public class Meat extends Food implements  Discountable{

    public Meat(int amount, double price) {
        super(amount, price);
        this.isVegetarian = false;
    }

    @Override
    public double getDiscount() {
        return 0; // скидки для мяса нет
    }

    @Override
    public int getAmount() {
        return amount;
    }

    @Override
    public double getPrice() {
        return price;
    }
}





