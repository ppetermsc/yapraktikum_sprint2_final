package model.constants;

public class Colour {

    public static final String RED = "red";
    public static final String GREEN = "green";
}
